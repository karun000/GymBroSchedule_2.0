#pragma once

#include <jsi/jsi.h>
#include <worklets/AnimationFrameQueue/AnimationFrameBatchinator.h>
#include <worklets/NativeModules/JSIWorkletsModuleProxy.h>
#include <worklets/SharedItems/MemoryManager.h>
#include <worklets/SharedItems/UnpackerLoader.h>
#include <worklets/Tools/JSLogger.h>
#include <worklets/Tools/JSScheduler.h>
#include <worklets/Tools/ScriptBuffer.h>
#include <worklets/Tools/SingleInstanceChecker.h>
#include <worklets/Tools/UIScheduler.h>
#include <worklets/WorkletRuntime/BundleModeConfig.h>
#include <worklets/WorkletRuntime/RuntimeManager.h>
#include <worklets/WorkletRuntime/WorkletRuntime.h>

#include <memory>

namespace worklets {

class WorkletsModuleProxy : public std::enable_shared_from_this<WorkletsModuleProxy> {
 public:
  void start();

  explicit WorkletsModuleProxy(
      jsi::Runtime &rnRuntime,
      const std::shared_ptr<CallInvoker> &jsCallInvoker,
      const std::shared_ptr<UIScheduler> &uiScheduler,
      std::function<bool()> &&isJavaScriptQueue,
      const std::shared_ptr<RuntimeBindings> &runtimeBindings,
      const BundleModeConfig &bundleModeConfig);

  ~WorkletsModuleProxy();

  [[nodiscard]] inline std::shared_ptr<JSScheduler> getJSScheduler() const {
    return jsScheduler_;
  }

  [[nodiscard]] inline std::shared_ptr<UIScheduler> getUIScheduler() const {
    return uiScheduler_;
  }

  [[nodiscard]] inline std::shared_ptr<JSLogger> getJSLogger() const {
    return jsLogger_;
  }

  [[nodiscard]] inline std::shared_ptr<WorkletRuntime> getUIWorkletRuntime() const {
    return uiWorkletRuntime_;
  }

  [[nodiscard]] inline bool isDevBundle() const {
    return isDevBundle_;
  }

 private:
  const bool isDevBundle_;
  const std::shared_ptr<JSScheduler> jsScheduler_;
  const std::shared_ptr<UIScheduler> uiScheduler_;
  const std::shared_ptr<JSLogger> jsLogger_;
  const std::shared_ptr<RuntimeBindings> runtimeBindings_;
  const BundleModeConfig bundleModeConfig_;
  const std::shared_ptr<MemoryManager> memoryManager_;
  const std::shared_ptr<RuntimeManager> runtimeManager_;
  const std::shared_ptr<UnpackerLoader> unpackerLoader_;
  std::shared_ptr<WorkletRuntime> uiWorkletRuntime_;
  const std::shared_ptr<JSIWorkletsModuleProxy> rnRuntimeProxy_;
  std::shared_ptr<AnimationFrameBatchinator> animationFrameBatchinator_;
#ifndef NDEBUG
  SingleInstanceChecker<WorkletsModuleProxy> singleInstanceChecker_;
#endif // NDEBUG
};

} // namespace worklets
