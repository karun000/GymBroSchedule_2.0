def worklets_try_to_parse_react_native_package_json(node_modules_dir)
  react_native_package_json_path = File.join(node_modules_dir, 'react-native/package.json')
  if !File.exist?(react_native_package_json_path)
    return nil
  end
  return JSON.parse(File.read(react_native_package_json_path))
end

def worklets_find_config()
  result = {
    :feature_flags_flag => nil,
    :fetch_preview_flag => nil,
    :is_reanimated_example_app => nil,
    :react_native_version => nil,
    :react_native_node_modules_dir => nil,
    :react_native_common_dir => nil,
  }

  react_native_node_modules_dir = File.join(File.dirname(`cd "#{Pod::Config.instance.installation_root.to_s}" && node --print "require.resolve('react-native/package.json')"`), '..')
  react_native_json = worklets_try_to_parse_react_native_package_json(react_native_node_modules_dir)

  if react_native_json == nil
    # user configuration, just in case
    node_modules_dir = ENV["REACT_NATIVE_NODE_MODULES_DIR"]
    react_native_json = worklets_try_to_parse_react_native_package_json(node_modules_dir)
  end

  if react_native_json == nil
    raise '[Worklets] Unable to recognize your `react-native` version. Please set environmental variable with `react-native` location: `export REACT_NATIVE_NODE_MODULES_DIR="<path to react-native>" && pod install`.'
  end

  result[:is_reanimated_example_app] = ENV["IS_REANIMATED_EXAMPLE_APP"] != nil
  result[:react_native_version] = react_native_json['version']
  result[:react_native_node_modules_dir] = File.expand_path(react_native_node_modules_dir)

  pods_root = Pod::Config.instance.project_pods_root
  react_native_common_dir_absolute = File.join(react_native_node_modules_dir, 'react-native', 'ReactCommon')
  react_native_common_dir_relative = Pathname.new(react_native_common_dir_absolute).relative_path_from(pods_root).to_s
  result[:react_native_common_dir] = react_native_common_dir_relative

  feature_flags = worklets_get_static_feature_flags()
  result[:feature_flags_flag] = worklets_get_static_feature_flags_flag(feature_flags)
  result[:fetch_preview_flag] = worklets_get_flag_from_feature_flags(feature_flags, 'FETCH_PREVIEW_ENABLED')
  
  return result
end

def worklets_assert_minimal_react_native_version(config)
  validate_react_native_version_script = File.expand_path(File.join(__dir__, 'validate-react-native-version.js'))
  unless system("node \"#{validate_react_native_version_script}\" #{config[:react_native_version]}")
    raise "[Worklets] Your installed version of React Native is not compatible with installed version of Worklets. See the documentation for the list of supported versions: https://docs.swmansion.com/react-native-worklets/docs/guides/compatibility/"
  end
end

def worklets_get_flag_from_feature_flags(feature_flags, flag_name)
  if feature_flags[flag_name] == 'true'
    return "-DWORKLETS_#{flag_name}"
  else
    return ''
  end
end

def worklets_get_static_feature_flags()
  feature_flags = {}

  static_feature_flags_path = File.path('./src/featureFlags/staticFlags.json')
  if !File.exist?(static_feature_flags_path)
    raise "[Worklets] Feature flags file not found at #{static_feature_flags_path}."
  end
  static_feature_flags_json = JSON.parse(File.read(static_feature_flags_path))
  static_feature_flags_json.each do |key, value|
    feature_flags[key] = value.to_s
  end

  package_json_path = File.join(Pod::Config.instance.installation_root.to_s, '..', 'package.json')
  if File.exist?(package_json_path)
    package_json = JSON.parse(File.read(package_json_path))
    if package_json['worklets'] && package_json['worklets']['staticFeatureFlags']
      feature_flags_json = package_json['worklets']['staticFeatureFlags']
      feature_flags_json.each do |key, value|
        feature_flags[key] = value.to_s
      end
    end
  end
  return feature_flags
end

def worklets_get_static_feature_flags_flag(feature_flags)
  return "-DWORKLETS_FEATURE_FLAGS=\"#{feature_flags.map { |key, value| "[#{key}:#{value}]" }.join('')}\""
end
